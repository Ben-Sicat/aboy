# This entrypoint file to be used in development.
import budget
from budget import create_spend_chart
from unittest import main

# Define some categories
food = budget.Category("food")
clothing = budget.Category("clothing")
auto = budget.Category("auto")

# Make some deposits and withdrawals

food.deposit(1000, "Initial deposit")
food.withdraw(10.15, "Groceries")
food.withdraw(15.89, "Restaurant and more food for dessert")
print(food.get_balance())
food.transfer(50, clothing)

clothing.withdraw(25.55)
clothing.withdraw(100)

auto.deposit(1000, "Initial deposit")
auto.withdraw(15)

print(food)
print(clothing)

# Create the spend chart
chart = create_spend_chart([food, clothing, auto])

# Print the chart
print(chart)


# Run unit tests automatically
main(module='test_module', exit=False)
